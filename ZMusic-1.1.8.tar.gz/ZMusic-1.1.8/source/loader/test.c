// This file is only here to have one module that includes the header from a pure C source, so that it immediately errors out when something incompatible is found.
#include "zmusic.h"