#include "rhythmdata.h"

const unsigned char* rhythmdata[6] = {
    BD_2608, SD_2608, TOP_2608, HH_2608, TOM_2608, RIM_2608
};
