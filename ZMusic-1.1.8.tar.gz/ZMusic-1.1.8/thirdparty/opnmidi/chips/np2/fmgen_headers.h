#ifndef WIN_HEADERS_H
#define WIN_HEADERS_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <assert.h>

#endif	// WIN_HEADERS_H
